﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WEBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CalcController : ControllerBase
    {
        [HttpPost(Name = "Calculate")]
        public decimal Post([FromBody] CalcDTO calcDTO)
        {
            return calcDTO.Operation switch
            {
                "plus" => calcDTO.Operand1 + calcDTO.Operand2,
                "minus" => calcDTO.Operand1 - calcDTO.Operand2,
                "krat" => calcDTO.Operand1 * calcDTO.Operand2,
                "deleno" => calcDTO.Operand1 / calcDTO.Operand2                 
            };            
        }
    }
}
