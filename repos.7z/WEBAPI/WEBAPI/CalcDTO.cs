﻿namespace WEBAPI
{
    public class CalcDTO
    {
        public decimal Operand1 { get; set; }
        public decimal Operand2 { get; set; }
        public string Operation { get; set; }
    }
}
