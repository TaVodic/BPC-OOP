﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WEBAPI;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private HttpClient _client;
        public MainWindow()
        {
            InitializeComponent();
            _client = new HttpClient();
            _client.BaseAddress = new Uri("https://localhost:7037/");
            _client.DefaultRequestHeaders.Accept.Clear();
            _client.DefaultRequestHeaders.Accept.Add(new
            MediaTypeWithQualityHeaderValue("application/json"));
        }

        private async void Calculate_Click(object sender, RoutedEventArgs e)
        {
            CalcDTO calcDTO = new CalcDTO();
            calcDTO.Operand1 = Convert.ToDecimal(num1.Text);
            calcDTO.Operand2 = Convert.ToDecimal(num2.Text);
            calcDTO.Operation = ((ComboBoxItem)operatorGUI.SelectedValue).Tag.ToString();

            HttpResponseMessage response = await _client.PostAsJsonAsync($"api/calc", calcDTO);
            response.EnsureSuccessStatusCode();

            string result = response.Content.ReadAsStringAsync().Result;
            vylsedek.Content = result;
        }
    }
}
